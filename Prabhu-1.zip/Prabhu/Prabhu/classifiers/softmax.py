from builtins import range
import numpy as np
from random import shuffle
from past.builtins import xrange

def softmax_loss_naive(W, X, y, reg):
    """
    Softmax loss function, naive implementation (with loops)

    Inputs have dimension D, there are C classes, and we operate on minibatches
    of N examples.

    Inputs:
    - W: A numpy array of shape (D, C) containing weights.
    - X: A numpy array of shape (N, D) containing a minibatch of data.
    - y: A numpy array of shape (N,) containing training labels; y[i] = c means
      that X[i] has label c, where 0 <= c < C.
    - reg: (float) regularization strength

    Returns a tuple of:
    - loss as single float
    - gradient with respect to weights W; an array of same shape as W
    """
    # Initialize the loss and gradient to zero.
    loss = 0.0
    dW = np.zeros_like(W)

    #############################################################################
    # TODO: Compute the softmax loss and its gradient using explicit loops.     #
    # Store the loss in loss and the gradient in dW. If you are not careful     #
    # here, it is easy to run into numeric instability. Don't forget the        #
    # regularization!                                                           #
    #############################################################################
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
    
    # for class vector 
    num_classes = W.shape[1]
    #since X is N X D we need to convert it into shape D as given in naive implementation of svm.py
    num_train = X.shape[0]
    #using for loops to calculate loss and gradient for softmax classifier
    
    j=0;
    for j in range(num_train):
        scores = np.dot(X[j], W) # we take dot product of X and w as earlier 
        #find the max score to make the max value 0 as given in documentation
        max_score = np.max(scores)
        #subtract the max score from each score  
        scores = scores - max_score
        
        p_num = np.exp(scores) #from the forumla for softmax
        p_denominator = np.sum(p_num) #using the formula 
        #find the probability
        probability = p_num / p_denominator
        #now to compute loss we take the log of the probabilty found in prev step 
        loss  = loss  - np.log(probability[y[j]])
        
        #computing the gradient for softmax classifier
        for k in range(num_classes):
            probability_dash = probability[k]*X[j]
            #as per formula we mulitpliy x with softmax function
            dW[:, k] = probability_dash + dW[ :,k]     
        #overall gradient by subtracting minibatch data
        dW[:, y[j]] = dW[:, y[j]] - X[j]
        
        #i=i+1
    #finding regularization facotr for loss 
    reg_factor = reg * np.sum(W*W)
    #finding reg factor for gradient 
    reg_grad = 2 * reg *W
    #computing the overall gradient 
    dW = dW/num_train + reg_grad
    #finding average and adding the regularization to find total entropy loss for softmax
    loss = loss/num_train + reg_factor

     

    

    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    return loss, dW


def softmax_loss_vectorized(W, X, y, reg):
    """
    Softmax loss function, vectorized version.

    Inputs and outputs are the same as softmax_loss_naive.
    """
    # Initialize the loss and gradient to zero.
    loss = 0.0
    dW = np.zeros_like(W)

    #############################################################################
    # TODO: Compute the softmax loss and its gradient using no explicit loops.  #
    # Store the loss in loss and the gradient in dW. If you are not careful     #
    # here, it is easy to run into numeric instability. Don't forget the        #
    # regularization!                                                           #
    #############################################################################
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
    #compute scores using w and x
    scores = np.dot(X, W)
    # for class vector 
    #num_classes = W.shape[1]
    #since X is N X D we need to convert it into shape D as given in naive implementation of svm.py
    num_train = X.shape[0]
    train_num = np.arange(num_train)
    #subtract the max score to make sure min value is zero in scores 
    max_score = np.max(scores, keepdims=True,axis=1)
    scores = scores - max_score
    scores_new = scores
    #computing the numerator term of the probability for softmax
    prob_num = np.exp(scores_new)
    #computing the denominator term for probability
    prob_den = np.sum(prob_num, keepdims=True,axis=1)
    #the actual probability
    probability = prob_num/ prob_den 
    
    #finding the vectorised softmax loss function  and summing it and thus finding average for train samples
    vector_loss = (np.sum(-np.log(probability[train_num, y])) ) / num_train
    
    
    #adding regularization term to the above computed loss
    loss  = vector_loss  + reg * np.sum(W*W)
    
    x_trans = X.T
    #compute the gradient using the scores
    probability[train_num, y ] -=1
    #now we calcualte dw which is dot product of transpose of X and probability
    
    dW= np.dot(x_trans, probability)
    #final gradient taking average and adding regularization term is 
    dW = dW /num_train + 2*reg*W
    
    
    
    

    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    return loss, dW
