from builtins import range
import numpy as np
from random import shuffle
from past.builtins import xrange

def svm_loss_naive(W, X, y, reg):
    """
    Structured SVM loss function, naive implementation (with loops).

    Inputs have dimension D, there are C classes, and we operate on minibatches
    of N examples.

    Inputs:
    - W: A numpy array of shape (D, C) containing weights.
    - X: A numpy array of shape (N, D) containing a minibatch of data.
    - y: A numpy array of shape (N,) containing training labels; y[i] = c means
      that X[i] has label c, where 0 <= c < C. 
    - reg: (float) regularization strength

    Returns a tuple of:
    - loss as single float
    - gradient with respect to weights W; an array of same shape as W
    """
    dW = np.zeros(W.shape) # initialize the gradient as zero

    # compute the loss and the gradient
    num_classes = W.shape[1]
    num_train = X.shape[0]
    loss = 0.0
    for i in range(num_train):
        num_classes_greater_margin = 0
        scores = X[i].dot(W)
        correct_class_score = scores[y[i]]
        for j in range(num_classes):
            if j == y[i]:
                continue
            margin = scores[j] - correct_class_score + 1 # note delta = 1
            if margin > 0:
                
                dW[:, j] = dW[:,j] +  X[i, :]
                loss += margin
                num_classes_greater_margin = num_classes_greater_margin +1
                #we now compute gradieent of correct class
        dW[:, y[i]] = dW[:, y[i]] - X[i, :]*num_classes_greater_margin

    # Right now the loss is a sum over all training examples, but we want it
    # to be an average instead so we divide by num_train.
    loss /= num_train
    dW = dW/ num_train
    # Add regularization to the loss.
    loss += reg * np.sum(W * W)
    
   

    #############################################################################
    # TODO:                                                                     #
    # Compute the gradient of the loss function and store it dW.                #
    # Rather that first computing the loss and then computing the derivative,   #
    # it may be simpler to compute the derivative at the same time that the     #
    # loss is being computed. As a result you may need to modify some of the    #
    # code above to compute the gradient.                                       #
    #############################################################################
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
    dW= dW + 2*reg*W 

    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
    
    return loss, dW



def svm_loss_vectorized(W, X, y, reg):
    """
    Structured SVM loss function, vectorized implementation.

    Inputs and outputs are the same as svm_loss_naive.
    """
    loss = 0.0
    dW = np.zeros(W.shape) # initialize the gradient as zero

    #############################################################################
    # TODO:                                                                     #
    # Implement a vectorized version of the structured SVM loss, storing the    #
    # result in loss.                                                           #
    #############################################################################
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    scores = np.dot(X, W) #Caclulate the score using X and weight w
    
    num_train = X.shape[0]
    #now we need to score for correct classes which are referred as correct scores
    num_train_r = np.arange(num_train) #np.linspace(0,num_train,1) #use this
    #now we compute the actual correct score to find loss
    #correct_score = scores[:,y] 
    
    correct_score = scores[num_train_r, y].reshape(-1,1)
    
    #now we have to find the data loss or also called hinge loss-
    score_diff = scores - correct_score + 1  #here delta is nothing but 1
    
    hinge_loss = np.maximum(0, score_diff)
    #we have to not include correct class score in the total loss
    
    hinge_loss[num_train_r, y] =0
    #calculating the average hinge loss we get 
    
    #avg_loss = np.sum(hinge_loss)/ num_train
    #total  vectorised loss  is therefore
    loss = np.sum(hinge_loss)/ num_train + reg * np.sum(W * W)

    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    #############################################################################
    # TODO:                                                                     #
    # Implement a vectorized version of the gradient for the structured SVM     #
    # loss, storing the result in dW.                                           #
    #                                                                           #
    # Hint: Instead of computing the gradient from scratch, it may be easier    #
    # to reuse some of the intermediate values that you used to compute the     #
    # loss.                                                                     #
    #############################################################################
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
    
    shp = hinge_loss.shape
    
    actual_margin_msk = np.zeros(shp)
    #find where the hinge loss or margin is greater than zero 
    flag = hinge_loss > 0
    #where it is greater than 0 for those i mask it as 1 rest all 0s 
    actual_margin_msk[flag]= 1
    #here we find how many times actual margin was greater than zero 
    sum_margin  =  actual_margin_msk.sum(1) #np.sum(actual_margin_msk, axis =1 )
    actual_margin_msk[num_train_r, y] = -sum_margin
    
    
    
    #gradient is found , X.T.shape is D x N 
    dW = np.dot(X.T,actual_margin_msk) #  actual_margin_mask.shape is N x C 
    dW = dW/num_train + 2 *reg*W  #adding the reguralization term too 

    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    return loss, dW
