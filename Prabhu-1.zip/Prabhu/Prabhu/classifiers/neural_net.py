from __future__ import print_function

from builtins import range
from builtins import object
import numpy as np
import matplotlib.pyplot as plt
from past.builtins import xrange

class TwoLayerNet(object):
    """
    A two-layer fully-connected neural network. The net has an input dimension of
    N, a hidden layer dimension of H, and performs classification over C classes.
    We train the network with a softmax loss function and L2 regularization on the
    weight matrices. The network uses a ReLU nonlinearity after the first fully
    connected layer.

    In other words, the network has the following architecture:

    input - fully connected layer - ReLU - fully connected layer - softmax

    The outputs of the second fully-connected layer are the scores for each class.
    """

    def __init__(self, input_size, hidden_size, output_size, std=1e-4):
        """
        Initialize the model. Weights are initialized to small random values and
        biases are initialized to zero. Weights and biases are stored in the
        variable self.params, which is a dictionary with the following keys:

        W1: First layer weights; has shape (D, H)
        b1: First layer biases; has shape (H,)
        W2: Second layer weights; has shape (H, C)
        b2: Second layer biases; has shape (C,)

        Inputs:
        - input_size: The dimension D of the input data.
        - hidden_size: The number of neurons H in the hidden layer.
        - output_size: The number of classes C.
        """
        self.params = {}
        self.params['W1'] = std * np.random.randn(input_size, hidden_size)
        self.params['b1'] = np.zeros(hidden_size)
        self.params['W2'] = std * np.random.randn(hidden_size, output_size)
        self.params['b2'] = np.zeros(output_size)

    def loss(self, X, y=None, reg=0.0):
        """
        Compute the loss and gradients for a two layer fully connected neural
        network.

        Inputs:
        - X: Input data of shape (N, D). Each X[i] is a training sample.
        - y: Vector of training labels. y[i] is the label for X[i], and each y[i] is
          an integer in the range 0 <= y[i] < C. This parameter is optional; if it
          is not passed then we only return scores, and if it is passed then we
          instead return the loss and gradients.
        - reg: Regularization strength.

        Returns:
        If y is None, return a matrix scores of shape (N, C) where scores[i, c] is
        the score for class c on input X[i].

        If y is not None, instead return a tuple of:
        - loss: Loss (data loss and regularization loss) for this batch of training
          samples.
        - grads: Dictionary mapping parameter names to gradients of those parameters
          with respect to the loss function; has the same keys as self.params.
        """
        # Unpack variables from the params dictionary
        W1, b1 = self.params['W1'], self.params['b1']
        W2, b2 = self.params['W2'], self.params['b2']
        N, D = X.shape

        # Compute the forward pass
        scores = None
        #############################################################################
        # TODO: Perform the forward pass, computing the class scores for the input. #
        # Store the result in the scores variable, which should be an array of      #
        # shape (N, C).                                                             #
        #############################################################################
        # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

        #we initally compute forward pass  where dot product of weight and x is required
        prod = X.dot(W1) 
        
        #before we pass it to activation function we need to add the sufficient bias 
        first_layer = prod + b1
        
        #next we passs it to activation functiom in which case we use relua
        #in relu we return the element if >0 or just return 0 otherwise
        
        first_layer[first_layer<=0 ] = 0
        
        #now we compute the 2nd layer activation where the first layer result is used as input and we get dot product with w2
        
        second_layer_prd = first_layer.dot(W2) #np.dot(first_layer, W2)
        #adding the bias to layer 2 we get 
        second_layer = second_layer_prd + b2
        #store the result in scores
        scores = second_layer

        # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

        # If the targets are not given then jump out, we're done
        if y is None:
            return scores

        # Compute the loss
        loss = None
        #############################################################################
        # TODO: Finish the forward pass, and compute the loss. This should include  #
        # both the data loss and L2 regularization for W1 and W2. Store the result  #
        # in the variable loss, which should be a scalar. Use the Softmax           #
        # classifier loss.                                                          #
        #############################################################################
        # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
        #get values from N 
        N_values = np.arange(N)
        #since we have to use softmax classifier for loss we need to initially arrange scores
        #such that max score is 0 to attain better stability
        max_scores = scores.max()
        #calculate the probability based on the scores for softmax loss
        #finding the numerator of the probability we get 
        prob_num = np.exp(scores - max_scores)
        # finding the denominator of the probability where the sum of the exp of the scores is found 
        prob_den = np.sum(prob_num, axis =1, keepdims = True )
        #computing the softmax probability 
        soft_max_prob = prob_num / prob_den
        derivative_prob = soft_max_prob
        #once we get the prob we calculate the loss using summation of -log(p) formula
        #where we select correct values for p before taking log
        soft_max_loss = -np.log(soft_max_prob[N_values, y])
        reg_bias = np.sum(b1*b1)
        #we take the sum of the loss on all the training data and then take its average
        #before adding the regularization term 
        loss = np.sum(soft_max_loss) / N
        
        #next we add the regularization term since we finding the loss for 2 layer neural network 
        #we need to take into consideration weights W1 and W2 as well
        
        loss = loss + reg * (np.sum(W2*W2) + np.sum(W1*W1) + reg_bias )
        
        

        # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

        # Backward pass: compute gradients
        grads = {}
        #############################################################################
        # TODO: Compute the backward pass, computing the derivatives of the weights #
        # and biases. Store the results in the grads dictionary. For example,       #
        # grads['W1'] should store the gradient on W1, and be a matrix of same size #
        #############################################################################
        # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
        #transpose of X vector of input data having dim Nx D
        X_trans = X.T
        #finding the transpose of weights W2.
        W2_trans = W2.T
        # we find the derivative of the probabiltiy or the scores we calculated for softmax function in the upper part 
        #using the formula  dL/df = -1 + dL/df , here f means the 2nd layer function since we apply backprop method 
        derivative_prob[N_values, y] = -1 + derivative_prob[N_values, y]
        #here we find the gradient of the bias parameter b2
        db2 = np.sum(derivative_prob/N, axis =0, keepdims = False )
        
        #storing the deriative of bias b2 in grads dictionary
        grads['b2'] = db2
        #finding transpose of first layer f relu
        first_layer_transpose = first_layer.T
        #here to find the gradient wrt to  weight parameter W2 
        #we need to  find derivative of score which is  f.w2 in layer 2 
        # we use the formula dw2 = dot product of (score and f transpose) and applying the same formula 
        dW2 = np.dot(first_layer_transpose , derivative_prob/N)
        #storing the found dW2 in grads dictionary along with the regularization term too 
        grads['W2'] = reg*2*W2 +dW2
        
        #in this part we compute the gradient wrt to W1 and bias parameter b1
        #finding the derivative of relu function using formula f' = derivative of softmax score . W2 transpose
        der_relu_function = (derivative_prob/N).dot(W2_trans)
        #Since in relu function any value lesser than zero is zero therefore the derivatvie becomes zero for those vlues 
        #which we just validate here 
        der_relu_function[ first_layer ==0 ] = 0
        db1 = np.sum(der_relu_function, axis=0, keepdims = False)
        
        #computing the derivative of weights param W1
        #since first layer activation f = x.w1 +b ,w1 = f* x transpose 
        #hence dw1 is based on dot product of derivative of relu and x transpose and since both terms are already computed above
        dW1 = np.dot(X_trans , der_relu_function )
        #fidnig regularization term for dW1 we get 
        regular_termw1 = 2*reg *W1
        
        grads['b1'] = db1
        #we store the final derivative of w1 along with regularization term found above
        
        grads['W1'] = regular_termw1 + dW1
        
        
        

        # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

        return loss, grads

    def train(self, X, y, X_val, y_val,
              learning_rate=1e-3, learning_rate_decay=0.95,
              reg=5e-6, num_iters=100,
              batch_size=200, verbose=False):
        """
        Train this neural network using stochastic gradient descent.

        Inputs:
        - X: A numpy array of shape (N, D) giving training data.
        - y: A numpy array f shape (N,) giving training labels; y[i] = c means that
          X[i] has label c, where 0 <= c < C.
        - X_val: A numpy array of shape (N_val, D) giving validation data.
        - y_val: A numpy array of shape (N_val,) giving validation labels.
        - learning_rate: Scalar giving learning rate for optimization.
        - learning_rate_decay: Scalar giving factor used to decay the learning rate
          after each epoch.
        - reg: Scalar giving regularization strength.
        - num_iters: Number of steps to take when optimizing.
        - batch_size: Number of training examples to use per step.
        - verbose: boolean; if true print progress during optimization.
        """
        num_train = X.shape[0]
        iterations_per_epoch = max(num_train / batch_size, 1)

        # Use SGD to optimize the parameters in self.model
        loss_history = []
        train_acc_history = []
        val_acc_history = []

        for it in range(num_iters):
            X_batch = None
            y_batch = None

            #########################################################################
            # TODO: Create a random minibatch of training data and labels, storing  #
            # them in X_batch and y_batch respectively.                             #
            #########################################################################
            # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
            #idx = np.random.permutation(num_train)[0:batch_size]
            idx = np.arange(len(X))
            np.random.shuffle(idx)
            
            
            
            #get the random indices of for y batch and x batch  
            y_batch = y[idx]
            X_batch = X[idx]
            
            pass
            # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

            # Compute loss and gradients using the current minibatch
            loss, grads = self.loss(X_batch, y=y_batch, reg=reg)
            loss_history.append(loss)

            #########################################################################
            # TODO: Use the gradients in the grads dictionary to update the         #
            # parameters of the network (stored in the dictionary self.params)      #
            # using stochastic gradient descent. You'll need to use the gradients   #
            # stored in the grads dictionary defined above.                         #
            #########################################################################
            # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
            #updating the bias parameters b1 and b2 
            self.params['b1'] = -grads['b1']*learning_rate + self.params['b1']
            self.params['b2'] = -grads['b2']*learning_rate  + self.params['b2']
            #updating the weights W 1 and W2
            self.params['W2'] = -grads['W2']*learning_rate + self.params['W2']
            
            self.params['W1'] = -grads['W1']*learning_rate + self.params['W1']

            

            

            
            

            # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

            if verbose and it % 100 == 0:
                print('iteration %d / %d: loss %f' % (it, num_iters, loss))

            # Every epoch, check train and val accuracy and decay learning rate.
            if it % iterations_per_epoch == 0:
                # Check accuracy
                train_acc = (self.predict(X_batch) == y_batch).mean()
                val_acc = (self.predict(X_val) == y_val).mean()
                train_acc_history.append(train_acc)
                val_acc_history.append(val_acc)

                # Decay learning rate
                learning_rate *= learning_rate_decay

        return {
          'loss_history': loss_history,
          'train_acc_history': train_acc_history,
          'val_acc_history': val_acc_history,
        }

    def predict(self, X):
        """
        Use the trained weights of this two-layer network to predict labels for
        data points. For each data point we predict scores for each of the C
        classes, and assign each data point to the class with the highest score.

        Inputs:
        - X: A numpy array of shape (N, D) giving N D-dimensional data points to
          classify.

        Returns:
        - y_pred: A numpy array of shape (N,) giving predicted labels for each of
          the elements of X. For all i, y_pred[i] = c means that X[i] is predicted
          to have class c, where 0 <= c < C.
        """
        y_pred = None

        ###########################################################################
        # TODO: Implement this function; it should be VERY simple!                #
        ###########################################################################
        # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
        #to find the predicted y value we need to consider the scores of the 2 layer neural network 
        #computing the first layer we get 
        neural_net_first  = X.dot(self.params['W1'])
        neural_first_lyr = neural_net_first + self.params['b1']
        #next we find the activtion function which is relu 
        neural_first_lyr_out = np.maximum(0,neural_first_lyr)
        #[ neural_first_lyr <=0  ]=0
        #this when goes to the second layer is weighed with w2
        second_lyr = np.dot(neural_first_lyr_out, self.params['W2'])
        final_score = second_lyr + self.params['b2']
        y_pred = np.argmax(final_score, axis =1)                    
        
        
        
        # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

        return y_pred
